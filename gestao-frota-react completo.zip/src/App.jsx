import React, { useEffect, useMemo, useState } from 'react'
import Sidebar from './components/Sidebar.jsx'
import Weekly from './pages/Weekly.jsx'
import Fuel from './pages/Fuel.jsx'
import Owners from './pages/Owners.jsx'
import Cars from './pages/Cars.jsx'
import Drivers from './pages/Drivers.jsx'
import Costs from './pages/Costs.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Receipts from './pages/Receipts.jsx'
import { defaultDB, loadDB, saveDB } from './lib/db.js'

const TABS = [
  {id:'weekly', label:'Pagamentos Semanais', icon:'💸'},
  {id:'fuel', label:'FuelPrices', icon:'⛽'},
  {id:'owners', label:'Pagamentos Donos', icon:'🤝'},
  {id:'cars', label:'Controle de Carros', icon:'🚗'},
  {id:'drivers', label:'Controle de Motoristas', icon:'🧑‍✈️'},
  {id:'costs', label:'Custos Fixos & Variáveis', icon:'🧾'},
  {id:'dashboard', label:'Resumo / Dashboard', icon:'📊'},
  {id:'receipts', label:'Recibos', icon:'🧾'},
]

export default function App(){
  const [collapsed, setCollapsed] = useState(false)
  const [tab, setTab] = useState('weekly')
  const [db, setDb] = useState(loadDB())

  useEffect(()=>{ saveDB(db) }, [db])

  const actions = useMemo(()=>({
    resetDB: ()=> setDb(defaultDB),
    setDb,
    add: (key, item)=> setDb(p=>({...p,[key]:[item, ...p[key]]})),
    upsert: (key, item)=> setDb(p=>{
      const idx = p[key].findIndex(x=>x.id===item.id)
      let arr = [...p[key]]
      if(idx>=0){ arr[idx] = item } else { arr = [item, ...arr] }
      return {...p,[key]:arr}
    }),
    remove: (key, id)=> setDb(p=>({...p,[key]:p[key].filter(x=>x.id!==id)})),
  }), [])

  return (
    <div className="app">
      <Sidebar
        collapsed={collapsed}
        onToggle={()=>setCollapsed(v=>!v)}
        tabs={TABS}
        active={tab}
        onSelect={setTab}
        onExport={()=>{
          const blob = new Blob([JSON.stringify(db,null,2)], {type:'application/json'})
          const a = document.createElement('a')
          a.href = URL.createObjectURL(blob)
          a.download = 'frota-dados.json'
          a.click()
          URL.revokeObjectURL(a.href)
        }}
        onImport={(json)=>{
          try{
            const data = JSON.parse(json)
            setDb(data)
            alert('Dados importados!')
          }catch(e){ alert('JSON inválido') }
        }}
      />
      <main>
        <header>
          <h1>{TABS.find(t=>t.id===tab)?.label}</h1>
          <div className="hint">Tudo é salvo automaticamente no seu navegador (LocalStorage).</div>
        </header>

        {tab==='weekly' && <Weekly db={db} actions={actions} />}
        {tab==='fuel' && <Fuel db={db} actions={actions} />}
        {tab==='owners' && <Owners db={db} actions={actions} />}
        {tab==='cars' && <Cars db={db} actions={actions} />}
        {tab==='drivers' && <Drivers db={db} actions={actions} />}
        {tab==='costs' && <Costs db={db} actions={actions} />}
        {tab==='dashboard' && <Dashboard db={db} />}
        {tab==='receipts' && <Receipts db={db} actions={actions} />}
      </main>
    </div>
  )
}
