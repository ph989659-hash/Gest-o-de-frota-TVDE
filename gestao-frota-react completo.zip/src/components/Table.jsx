import React from 'react'

export default function Table({columns, rows, onEdit, onDelete}){
  return (
    <table className="table">
      <thead><tr>{columns.map(c=>(<th key={c.key}>{c.label}</th>))}<th>Ações</th></tr></thead>
      <tbody>
        {rows.map(r=> (
          <tr key={r.id}>
            {columns.map(c=> (<td key={c.key}>{c.render? c.render(r[c.key], r) : (r[c.key] ?? '')}</td>))}
            <td>
              <div className="row-actions">
                <button className="tiny" onClick={()=>onEdit?.(r)}>Editar</button>
                <button className="tiny danger" onClick={()=>onDelete?.(r.id)}>Remover</button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
