import React, { useEffect, useRef } from 'react'
import { fmt } from '../lib/db'

export default function BarChart({data}){
  const ref = useRef()
  useEffect(()=>{
    const canvas = ref.current
    if(!canvas) return
    const ctx = canvas.getContext('2d')
    const W = canvas.clientWidth || 700
    const H = 260
    canvas.width = W
    canvas.height = H
    ctx.clearRect(0,0,W,H)
    const max = Math.max(...data.map(d=>Math.abs(d.val)), 1)
    const pad = 32, gap = 24
    const bw = (W - pad*2 - gap*(data.length-1))/data.length
    data.forEach((d,i)=>{
      const h = (Math.abs(d.val)/max) * (H - pad*2)
      const x = pad + i*(bw+gap)
      const y = H - pad - h
      ctx.fillStyle = d.val<0 ? '#dc2626' : '#1e88e5'
      ctx.fillRect(x, y, bw, h)
      ctx.fillStyle = '#111827'
      ctx.font = '12px system-ui'
      ctx.textAlign='center'
      ctx.fillText(d.label, x + bw/2, H - 10)
      ctx.fillText('€ ' + fmt(d.val), x + bw/2, y - 6)
    })
  }, [JSON.stringify(data)])
  return <canvas ref={ref} height={260} style={{width:'100%'}} />
}
