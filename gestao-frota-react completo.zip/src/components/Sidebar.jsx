import React, { useRef } from 'react'

export default function Sidebar({collapsed, onToggle, tabs, active, onSelect, onExport, onImport}){
  const fileRef = useRef()

  return (
    <aside className={collapsed?'closed':''}>
      <div className="brand">
        <button id="burger" onClick={onToggle} aria-label="Alternar menu">☰</button>
        <span className="brand-text">Gestão</span>
      </div>
      <nav>
        {tabs.map(t=>(
          <button key={t.id} className={'nav-item ' + (active===t.id?'active':'')} onClick={()=>onSelect(t.id)}>
            <span className="icon">{t.icon}</span>
            <span className="text">{t.label}</span>
          </button>
        ))}
        <div className="spacer" />
        <button className="nav-item subtle" onClick={onExport}>
          <span className="icon">⬇️</span><span className="text">Exportar JSON</span>
        </button>
        <label className="nav-item subtle">
          <span className="icon">⬆️</span><span className="text">Importar JSON</span>
          <input ref={fileRef} type="file" hidden accept="application/json"
            onChange={e=>{
              const file = e.target.files?.[0]
              if(!file) return
              const reader = new FileReader()
              reader.onload = ()=> onImport(reader.result)
              reader.readAsText(file)
              e.target.value = ''
            }}
          />
        </label>
      </nav>
    </aside>
  )
}
