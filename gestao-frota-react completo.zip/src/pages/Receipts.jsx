import React, { useMemo, useState } from 'react'
import Table from '../components/Table.jsx'
import { id, fmt, escapeHTML } from '../lib/db.js'

export default function Receipts({db, actions}){
  const [form, setForm] = useState({tipo:'motorista'})
  const [q, setQ] = useState('')

  const refs = form.tipo==='motorista' ? db.drivers : db.owners

  const rows = useMemo(()=> db.receipts.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())), [db.receipts, q])
  const cols = [{key:'date',label:'Data'},{key:'tipo',label:'Tipo'},{key:'ref',label:'Ref'},{key:'valor',label:'Valor (€)'}]

  function printAndSave(rec){
    const nome = (rec.tipo==='motorista' ? db.drivers.find(d=>d.id===rec.ref)?.name : db.owners.find(o=>o.id===rec.ref)?.name) || '-'
    const hoje = new Date().toLocaleDateString()
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Recibo</title>
    <style>
      body{font-family:system-ui; padding:24px}
      .recibo{max-width:620px; margin:0 auto; border:1px solid #ddd; border-radius:12px; padding:20px}
      h1{margin:0 0 8px 0} .muted{color:#555}
      .valor{font-size:1.4rem; font-weight:700; margin:12px 0}
      .assinatura{margin-top:48px; display:flex; justify-content:space-between}
    </style></head><body onload="window.print()">
    <div class="recibo">
      <h1>Recibo</h1>
      <div class="muted">${hoje}</div>
      <p>Recebido de: <strong>${escapeHTML(nome)}</strong> (${rec.tipo})</p>
      <div class="valor">Valor: € ${fmt(rec.valor)}</div>
      <p>Referência: ${rec.ref}</p>
      <div class="assinatura"><div>____________________<br/>Responsável</div><div>____________________<br/>Assinatura</div></div>
    </div></body></html>`;
    const w = window.open('', '_blank')
    w.document.write(html); w.document.close();
  }

  return (
    <section className="tab">
      <form className="card grid-4" onSubmit={e=>{
        e.preventDefault()
        if(!form.ref) return alert('Selecione a referência')
        const rec = { id: form.id || id(), tipo: form.tipo, ref: form.ref, valor: Number(form.valor)||0, date: new Date().toISOString().slice(0,10)}
        actions.upsert('receipts', rec)
        printAndSave(rec)
        setForm({tipo:form.tipo})
      }} onReset={()=>setForm({tipo:'motorista'})}>
        <div>
          <label>Tipo</label>
          <select value={form.tipo||'motorista'} onChange={e=>setForm(f=>({...f, tipo:e.target.value, ref:''}))}>
            <option value="motorista">Motorista</option>
            <option value="dono">Dono</option>
          </select>
        </div>
        <div>
          <label>Referência</label>
          <select value={form.ref||''} onChange={e=>setForm(f=>({...f, ref:e.target.value}))}>
            <option value="">Selecione...</option>
            {refs.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </div>
        <div>
          <label>Valor (€)</label>
          <input type="number" min="0" step="0.01" value={form.valor||''} onChange={e=>setForm(f=>({...f, valor:e.target.value}))} required/>
        </div>
        <div className="actions"><button className="primary">Gerar PDF</button><button type="reset" className="ghost">Limpar</button></div>
      </form>

      <div className="table-tools"><input placeholder="Pesquisar recibos..." value={q} onChange={e=>setQ(e.target.value)}/></div>
      <Table columns={cols} rows={rows} onEdit={setForm} onDelete={(id)=>actions.remove('receipts', id)} />
    </section>
  )
}
