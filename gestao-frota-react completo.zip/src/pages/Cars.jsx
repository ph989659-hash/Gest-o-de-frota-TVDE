import React, { useMemo, useState } from 'react'
import Table from '../components/Table.jsx'
import { id } from '../lib/db.js'

export default function Cars({db, actions}){
  const [form, setForm] = useState({state:'Limpo'})
  const [q, setQ] = useState('')
  const rows = useMemo(()=> db.cars.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())), [db.cars, q])
  const cols = [
    {key:'plate',label:'Placa'},
    {key:'insurance',label:'Seguro (vence)'},
    {key:'inspection',label:'Inspeção (vence)'},
    {key:'state',label:'Estado'},
  ]

  return (
    <section className="tab">
      <form className="card grid-4" onSubmit={e=>{
        e.preventDefault()
        if(!form.plate) return
        const rec = {...form, id: form.id || id()}
        actions.upsert('cars', rec); setForm({state:'Limpo'})
      }} onReset={()=>setForm({state:'Limpo'})}>
        <div><label>Placa</label><input value={form.plate||''} onChange={e=>setForm(f=>({...f, plate:e.target.value}))} required/></div>
        <div><label>Seguro - Vencimento</label><input type="date" value={form.insurance||''} onChange={e=>setForm(f=>({...f, insurance:e.target.value}))} required/></div>
        <div><label>Inspeção - Vencimento</label><input type="date" value={form.inspection||''} onChange={e=>setForm(f=>({...f, inspection:e.target.value}))} required/></div>
        <div>
          <label>Estado</label>
          <select value={form.state||'Limpo'} onChange={e=>setForm(f=>({...f, state:e.target.value}))}>
            <option>Limpo</option><option>Sujo</option><option>Arranhado</option><option>Em Reparos</option>
          </select>
        </div>
        <div className="actions"><button className="primary">Salvar</button><button type="reset" className="ghost">Limpar</button></div>
      </form>

      <div className="table-tools">
        <input placeholder="Pesquisar placa..." value={q} onChange={e=>setQ(e.target.value)}/>
      </div>
      <Table columns={cols} rows={rows} onEdit={setForm} onDelete={(id)=>actions.remove('cars', id)} />
    </section>
  )
}
