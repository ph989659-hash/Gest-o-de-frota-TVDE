import React, { useMemo, useState } from 'react'
import Table from '../components/Table.jsx'
import { id, fmt } from '../lib/db.js'

export default function Drivers({db, actions}){
  const [form, setForm] = useState({})
  const [q, setQ] = useState('')
  const rows = useMemo(()=> db.drivers.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())), [db.drivers, q])
  const cols = [
    {key:'name',label:'Nome'},
    {key:'docValid',label:'Doc Válido Até'},
    {key:'caucao',label:'Caução (€)', render:v=>fmt(v)},
    {key:'caucaoSem',label:'Desconto Semanal (€)', render:v=>fmt(v)},
  ]

  return (
    <section className="tab">
      <form className="card grid-4" onSubmit={e=>{
        e.preventDefault()
        if(!form.name) return
        const rec = {...form, id: form.id || id()}
        actions.upsert('drivers', rec); setForm({})
      }} onReset={()=>setForm({})}>
        <div><label>Nome</label><input value={form.name||''} onChange={e=>setForm(f=>({...f, name:e.target.value}))} required/></div>
        <div><label>Documento Válido até</label><input type="date" value={form.docValid||''} onChange={e=>setForm(f=>({...f, docValid:e.target.value}))} required/></div>
        <div><label>Caução (€)</label><input type="number" min="0" step="0.01" value={form.caucao||0} onChange={e=>setForm(f=>({...f, caucao:e.target.value}))}/></div>
        <div><label>Desconto Semanal Caução (€)</label><input type="number" min="0" step="0.01" value={form.caucaoSem||0} onChange={e=>setForm(f=>({...f, caucaoSem:e.target.value}))}/></div>
        <div className="actions"><button className="primary">Salvar</button><button type="reset" className="ghost">Limpar</button></div>
      </form>

      <div className="table-tools">
        <input placeholder="Pesquisar motorista..." value={q} onChange={e=>setQ(e.target.value)}/>
      </div>
      <Table columns={cols} rows={rows} onEdit={setForm} onDelete={(id)=>actions.remove('drivers', id)} />
    </section>
  )
}
