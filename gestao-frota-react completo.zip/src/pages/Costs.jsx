import React, { useMemo, useState } from 'react'
import Table from '../components/Table.jsx'
import { id, fmt } from '../lib/db.js'

export default function Costs({db, actions}){
  const [f, setF] = useState({})
  const [v, setV] = useState({})
  const [qf, setQf] = useState('')
  const [qv, setQv] = useState('')

  const rowsF = useMemo(()=> db.fixedCosts.filter(r=>JSON.stringify(r).toLowerCase().includes(qf.toLowerCase())), [db.fixedCosts, qf])
  const rowsV = useMemo(()=> db.variableCosts.filter(r=>JSON.stringify(r).toLowerCase().includes(qv.toLowerCase())), [db.variableCosts, qv])

  return (
    <section className="tab">
      <div className="grid-2">
        <form className="card" onSubmit={e=>{
          e.preventDefault()
          if(!f.desc) return
          const rec = {...f, id: f.id || id()}
          actions.upsert('fixedCosts', rec); setF({})
        }} onReset={()=>setF({})}>
          <h3>Custos Fixos</h3>
          <label>Descrição</label>
          <input value={f.desc||''} onChange={e=>setF(x=>({...x, desc:e.target.value}))} required/>
          <label>Valor Mensal (€)</label>
          <input type="number" min="0" step="0.01" value={f.monthly||''} onChange={e=>setF(x=>({...x, monthly:e.target.value}))} required/>
          <div className="actions"><button className="primary">Adicionar</button><button type="reset" className="ghost">Limpar</button></div>
        </form>

        <form className="card" onSubmit={e=>{
          e.preventDefault()
          if(!v.desc || !v.date) return
          const rec = {...v, id: v.id || id()}
          actions.upsert('variableCosts', rec); setV({})
        }} onReset={()=>setV({})}>
          <h3>Custos Variáveis</h3>
          <label>Descrição</label>
          <input value={v.desc||''} onChange={e=>setV(x=>({...x, desc:e.target.value}))} required/>
          <label>Valor (€)</label>
          <input type="number" min="0" step="0.01" value={v.value||''} onChange={e=>setV(x=>({...x, value:e.target.value}))} required/>
          <label>Data</label>
          <input type="date" value={v.date||''} onChange={e=>setV(x=>({...x, date:e.target.value}))} required/>
          <div className="actions"><button className="primary">Adicionar</button><button type="reset" className="ghost">Limpar</button></div>
        </form>
      </div>

      <div className="grid-2">
        <div>
          <div className="table-tools"><input placeholder="Pesquisar fixos..." value={qf} onChange={e=>setQf(e.target.value)}/></div>
          <Table columns={[{key:'desc',label:'Descrição'},{key:'monthly',label:'Mensal (€)',render:v=>fmt(v)}]}
                 rows={rowsF} onEdit={setF} onDelete={id=>actions.remove('fixedCosts', id)} />
        </div>
        <div>
          <div className="table-tools"><input placeholder="Pesquisar variáveis..." value={qv} onChange={e=>setQv(e.target.value)}/></div>
          <Table columns={[{key:'desc',label:'Descrição'},{key:'value',label:'Valor (€)',render:v=>fmt(v)},{key:'date',label:'Data'}]}
                 rows={rowsV} onEdit={setV} onDelete={id=>actions.remove('variableCosts', id)} />
        </div>
      </div>
    </section>
  )
}
