import React, { useMemo, useState, useEffect } from 'react'
import Table from '../components/Table.jsx'
import { id, fmt } from '../lib/db.js'

export default function Weekly({db, actions}){
  const [form, setForm] = useState({})
  const [q, setQ] = useState('')

  useEffect(()=>{ // recalcular ao trocar driver/fuel/valores
    const mot = db.drivers.find(d=>d.id===form.driverId)
    const caucaoSem = mot ? (Number(mot.caucaoSem)||0) : 0
    const uber = +form.uber||0, bolt=+form.bolt||0, litros=+form.liters||0
    const preco = +form.fuelPrice||0, extras=+form.extras||0, ded=+form.deductions||0
    const bruto = uber+bolt
    const combustivel = litros*preco
    const liquido = bruto - combustivel - extras - ded - caucaoSem
    setForm(f=>({...f, caucaoAuto:caucaoSem, bruto, liquido }))
  // eslint-disable-next-line
  }, [form.driverId, form.uber, form.bolt, form.liters, form.fuelPrice, form.extras, form.deductions, db.drivers])

  const fuelsOpts = useMemo(()=>[{id:'', name:'-- Selecione --'}, ...db.fuels], [db.fuels])

  const rows = useMemo(()=> db.weeklyPayments.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())), [db.weeklyPayments, q])

  const cols = [
    {key:'week', label:'Semana'},
    {key:'driverId', label:'Motorista', render:v=> (db.drivers.find(d=>d.id===v)?.name || '-')},
    {key:'uber', label:'Uber (€)', render:v=>fmt(v)},
    {key:'bolt', label:'Bolt (€)', render:v=>fmt(v)},
    {key:'liters', label:'Litros', render:v=>fmt(v)},
    {key:'fuelPrice', label:'Preço/L', render:v=>(Number(v||0)).toFixed(3)},
    {key:'extras', label:'Custos', render:v=>fmt(v)},
    {key:'deductions', label:'Deduções', render:v=>fmt(v)},
    {key:'caucaoAuto', label:'Caução', render:v=>fmt(v)},
    {key:'liquido', label:'Líquido', render:v=>'€ '+fmt(v)},
  ]

  return (
    <section className="tab">
      <form className="card grid-4" onSubmit={e=>{
        e.preventDefault()
        if(!form.driverId) return alert('Selecione um motorista')
        const rec = {...form, id: form.id || id()}
        actions.upsert('weeklyPayments', rec)
        setForm({})
      }} onReset={()=>setForm({})}>
        <div>
          <label>Motorista</label>
          <select value={form.driverId||''} onChange={e=>setForm(f=>({...f, driverId:e.target.value}))}>
            {db.drivers.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
        <div>
          <label>Semana de</label>
          <input type="date" value={form.week||''} onChange={e=>setForm(f=>({...f, week:e.target.value}))} required/>
        </div>
        <div>
          <label>Uber (€)</label>
          <input type="number" min="0" step="0.01" value={form.uber||0} onChange={e=>setForm(f=>({...f, uber:e.target.value}))}/>
        </div>
        <div>
          <label>Bolt (€)</label>
          <input type="number" min="0" step="0.01" value={form.bolt||0} onChange={e=>setForm(f=>({...f, bolt:e.target.value}))}/>
        </div>

        <div>
          <label>Combustível</label>
          <select value={form.fuelId||''} onChange={e=>{
            const id = e.target.value
            const price = db.fuels.find(f=>f.id===id)?.price || 0
            setForm(f=>({...f, fuelId:id, fuelPrice:price}))
          }}>
            {fuelsOpts.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
        </div>
        <div>
          <label>Litros</label>
          <input type="number" min="0" step="0.01" value={form.liters||0} onChange={e=>setForm(f=>({...f, liters:e.target.value}))}/>
        </div>
        <div>
          <label>Preço/Litro (auto)</label>
          <input type="number" disabled value={form.fuelPrice||0}/>
        </div>
        <div>
          <label>Custos Extras</label>
          <input type="number" min="0" step="0.01" value={form.extras||0} onChange={e=>setForm(f=>({...f, extras:e.target.value}))}/>
        </div>

        <div>
          <label>Deduções</label>
          <input type="number" min="0" step="0.01" value={form.deductions||0} onChange={e=>setForm(f=>({...f, deductions:e.target.value}))}/>
        </div>
        <div>
          <label>Caução (auto)</label>
          <input type="number" disabled value={form.caucaoAuto||0}/>
        </div>
        <div>
          <label>Total Bruto</label>
          <input type="number" disabled value={fmt(form.bruto||0)}/>
        </div>
        <div>
          <label>Líquido a Pagar</label>
          <input type="number" disabled value={fmt(form.liquido||0)}/>
        </div>

        <div className="actions">
          <button className="primary">Salvar</button>
          <button type="reset" className="ghost">Limpar</button>
        </div>
      </form>

      <div className="table-tools">
        <input placeholder="Pesquisar motorista, semana..." value={q} onChange={e=>setQ(e.target.value)}/>
        <span className="small">{rows.length} registros</span>
      </div>
      <Table
        columns={cols}
        rows={rows}
        onEdit={(r)=> setForm(r)}
        onDelete={(id)=> actions.remove('weeklyPayments', id)}
      />
    </section>
  )
}
