import React, { useMemo, useState } from 'react'
import BarChart from '../components/BarChart.jsx'
import { fmt } from '../lib/db.js'

export default function Dashboard({db}){
  const [yymm, setYymm] = useState(()=> new Date().toISOString().slice(0,7))
  const [driverId, setDriverId] = useState('')

  const [yy, mm] = yymm.split('-').map(Number)
  const weekly = db.weeklyPayments.filter(w=>{
    if(!w.week) return false
    const d = new Date(w.week)
    const ok = d.getFullYear()===yy && (d.getMonth()+1)===mm
    const okDriver = driverId ? (w.driverId===driverId) : true
    return ok && okDriver
  })

  const totalBruto = weekly.reduce((s,w)=> s + (Number(w.uber)+Number(w.bolt)), 0)
  const totalComb = weekly.reduce((s,w)=> s + (Number(w.liters)*Number(w.fuelPrice)), 0)
  const totalDeds = weekly.reduce((s,w)=> s + Number(w.deductions) + Number(w.extras) + Number(w.caucaoAuto), 0)
  const totalFixos = db.fixedCosts.reduce((s,c)=> s + Number(c.monthly), 0)
  const totalVar = db.variableCosts.filter(v=>{
    if(!v.date) return false
    const d = new Date(v.date)
    return d.getFullYear()===yy && (d.getMonth()+1)===mm
  }).reduce((s,v)=> s + Number(v.value), 0)

  const totalCustos = totalComb + totalDeds + totalFixos + totalVar
  const lucro = totalBruto - totalCustos
  const receitaLiquida = totalBruto - (totalComb + totalDeds) // sem fixos+variáveis
  const kpis = [
    {label:'Receita Total (Bruta)', value: '€ ' + fmt(totalBruto)},
    {label:'Receita Líquida', value: '€ ' + fmt(receitaLiquida)},
    {label:'Custos Totais', value: '€ ' + fmt(totalCustos)},
    {label:'Lucro Líquido', value: '€ ' + fmt(lucro)},
  ]

  // série por semana (sum of weekly liquido)
  const byDriverName = id=> db.drivers.find(d=>d.id===id)?.name || '-'
  const series = weekly.map(w=>({
    label: new Date(w.week).toLocaleDateString(),
    val: Number(w.liquido)||0,
    driver: byDriverName(w.driverId)
  }))

  return (
    <section className="tab">
      <div className="card grid-4">
        <div>
          <label>Mês</label>
          <input type="month" value={yymm} onChange={e=>setYymm(e.target.value)} />
        </div>
        <div>
          <label>Filtrar Motorista</label>
          <select value={driverId} onChange={e=>setDriverId(e.target.value)}>
            <option value="">Todos</option>
            {db.drivers.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
      </div>

      <div className="kpi">
        {kpis.map((k,i)=>(
          <div key={i} className="stat">
            <div className="label">{k.label}</div>
            <div className="value">{k.value}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{marginTop:16}}>
        <h3 style={{marginTop:0}}>Líquido por Semana</h3>
        <BarChart data={series.length? series : [{label:'Sem dados', val:0}]} />
        <div className="small">Cada barra representa o líquido da semana (após combustíveis, deduções e caução).</div>
      </div>
    </section>
  )
}
