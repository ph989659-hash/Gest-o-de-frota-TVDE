import React, { useMemo, useState } from 'react'
import Table from '../components/Table.jsx'
import { id } from '../lib/db.js'

export default function Fuel({db, actions}){
  const [form, setForm] = useState({})
  const [q, setQ] = useState('')

  const rows = useMemo(()=> db.fuels.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())), [db.fuels, q])
  const cols = [{key:'name', label:'Combustível'}, {key:'price', label:'Preço/L'}]

  return (
    <section className="tab">
      <form className="card grid-3" onSubmit={e=>{
        e.preventDefault();
        if(!form.name) return
        const rec = {...form, id: form.id || id()}
        actions.upsert('fuels', rec); setForm({})
      }} onReset={()=>setForm({})}>
        <div>
          <label>Combustível</label>
          <input value={form.name||''} onChange={e=>setForm(f=>({...f, name:e.target.value}))} placeholder="Ex.: Gasolina 95" required/>
        </div>
        <div>
          <label>Preço/Litro (€)</label>
          <input type="number" min="0" step="0.001" value={form.price||''} onChange={e=>setForm(f=>({...f, price:e.target.value}))} required/>
        </div>
        <div className="actions"><button className="primary">Salvar</button><button type="reset" className="ghost">Limpar</button></div>
      </form>

      <div className="table-tools">
        <input placeholder="Pesquisar combustível..." value={q} onChange={e=>setQ(e.target.value)}/>
        <span className="small">{rows.length} itens</span>
      </div>
      <Table columns={cols} rows={rows} onEdit={setForm} onDelete={id=>actions.remove('fuels', id)} />
    </section>
  )
}
