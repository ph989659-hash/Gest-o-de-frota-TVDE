import React, { useMemo, useState } from 'react'
import Table from '../components/Table.jsx'
import { id } from '../lib/db.js'

export default function Owners({db, actions}){
  const [form, setForm] = useState({period:'semanal'})
  const [q, setQ] = useState('')

  const rows = useMemo(()=> db.owners.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())), [db.owners, q])
  const cols = [{key:'name',label:'Dono'},{key:'period',label:'Período'},{key:'value',label:'Valor (€)'}]

  return (
    <section className="tab">
      <form className="card grid-4" onSubmit={e=>{
        e.preventDefault()
        if(!form.name) return
        const rec = {...form, id: form.id || id()}
        actions.upsert('owners', rec); setForm({period:'semanal'})
      }} onReset={()=>setForm({period:'semanal'})}>
        <div><label>Dono</label><input value={form.name||''} onChange={e=>setForm(f=>({...f, name:e.target.value}))} required/></div>
        <div>
          <label>Periodicidade</label>
          <select value={form.period||'semanal'} onChange={e=>setForm(f=>({...f, period:e.target.value}))}>
            <option value="semanal">Semanal</option>
            <option value="mensal">Mensal</option>
          </select>
        </div>
        <div><label>Valor (€)</label><input type="number" min="0" step="0.01" value={form.value||''} onChange={e=>setForm(f=>({...f, value:e.target.value}))} required/></div>
        <div className="actions"><button className="primary">Salvar</button><button type="reset" className="ghost">Limpar</button></div>
      </form>

      <div className="table-tools">
        <input placeholder="Pesquisar dono..." value={q} onChange={e=>setQ(e.target.value)}/>
      </div>
      <Table columns={cols} rows={rows} onEdit={setForm} onDelete={(id)=>actions.remove('owners', id)} />
    </section>
  )
}
