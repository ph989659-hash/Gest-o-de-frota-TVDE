import React, { useState } from "react";

export default function App() {
  const [theme, setTheme] = useState("dark");

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    document.body.className = newTheme;
  };

  return (
    <div className="p-6">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gestão de Frota</h1>
        <button
          onClick={toggleTheme}
          className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
        >
          Alternar Tema
        </button>
      </header>

      <section>
        <h2 className="text-xl mb-4">📊 Dashboard</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="card">
            <h3 className="text-lg font-semibold">Receita Total</h3>
            <p className="text-2xl font-bold">€ 12.450</p>
          </div>
          <div className="card">
            <h3 className="text-lg font-semibold">Lucro Líquido</h3>
            <p className="text-2xl font-bold">€ 8.320</p>
          </div>
          <div className="card">
            <h3 className="text-lg font-semibold">Custos</h3>
            <p className="text-2xl font-bold">€ 4.130</p>
          </div>
        </div>
      </section>
    </div>
  );
}
